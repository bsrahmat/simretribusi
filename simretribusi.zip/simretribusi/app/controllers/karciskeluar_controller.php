<?php
class KarciskeluarController extends AppController {
	var $name = 'Karciskeluar';
	var $uses = array('Karciskeluar','Pejabat','Pemungut');

	function index() {
		$this->Karciskeluar->recursive = 0;
		$this->paginate = array('Karciskeluar'=>  array('limit'=>30, 'order'=>array('Karciskeluar.tanggal'=>'desc')));
		$this->set('karciskeluar', $this->paginate('Karciskeluar'));
	}
	function add() {
		if (!empty($this->data)) {
			$idpemungut = $this->data['Karciskeluar']['pemungut_id'];
			$this->Pemungut->recursive = -1;
			$dt = $this->Pemungut->read(null,$idpemungut);
			$this->data['Karciskeluar']['pemungut_nama'] = $dt['Pemungut']['nama'];
			$this->Karciskeluar->Karcismasuk->recursive = -1;
			$updatekarcismasuk = $this->Karciskeluar->Karcismasuk->read(null, $this->data['Karciskeluar']['karcismasuk_id']);
			$this->data['Karciskeluar']['nilaiperlembar'] = $updatekarcismasuk['Karcismasuk']['nilaiperlembar'];
			$this->data['Karciskeluar']['nilairupiah'] = $this->data['Karciskeluar']['nilaiperlembar'] *$this->data['Karciskeluar']['jumlahlembar'];
			$this->data['Karciskeluar']['karcisblmdisetor'] = $this->data['Karciskeluar']['jumlahlembar'];
			// Lakukan pengurangan terhadap stok karcis
			$stokbaru = $updatekarcismasuk['Karcismasuk']['stokkarcis'] - $this->data['Karciskeluar']['jumlahlembar'];
			// Cek apakah jumlah karcis yang diambil melebihi stok karcis yang ada ?
			if ($stokbaru==0) $updatekarcismasuk['Karcismasuk']['stokkarcis'] = 0;
			else if ($stokbaru < 0) {
				$karcismasuk = $this->Karciskeluar->Karcismasuk->find('list',array('conditions'=>array('stokkarcis >'=>'0'),'order'=>array('Karcismasuk.tanggal'=>'asc')));
				$pemungut = $this->Karciskeluar->Pemungut->find('list',array('order'=>array('Pemungut.nama'=>'asc')));
				$this->set(compact('karcismasuk', 'pemungut'));
				$this->Session->setFlash(__('Stok karcis tidak mencukupi jumlah pengambilan. Mohon ganti jumlah pengambilan karcis.', true),'default',array('class'=>'error-message'));
				return;
			} else $updatekarcismasuk['Karcismasuk']['stokkarcis'] = $stokbaru;
			//debug($this->data);debug($updatekarcismasuk);exit;
			$this->Karciskeluar->create();
			if ($this->Karciskeluar->save($this->data)) {
				$this->Karciskeluar->Karcismasuk->save($updatekarcismasuk);
				$this->Session->setFlash(__('Data telah disimpan', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
		$karcismasuk = $this->Karciskeluar->Karcismasuk->find('list',array('conditions'=>array('stokkarcis >'=>'0'),'order'=>array('Karcismasuk.tanggal'=>'asc')));
		if (empty($karcismasuk)){
			$this->Session->setFlash(__('Stok Karcis sudah habis. Harap mengambil Karcis dari Dispenda.', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$pemungut = $this->Karciskeluar->Pemungut->find('list',array('order'=>array('Pemungut.nama'=>'asc')));
		if (empty($pemungut)){
			$this->Session->setFlash(__('Data Pemungut belum ada. Silahkan tambahkan dahulu data Pemungut.', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$this->set(compact('karcismasuk', 'pemungut'));
	}
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$idpemungut = $this->data['Karciskeluar']['pemungut_id'];
			$this->Pemungut->recursive = -1;
			$dt = $this->Pemungut->read(null,$idpemungut);
			$this->data['Karciskeluar']['pemungut_nama'] = $dt['Pemungut']['nama'];
			if (!empty($this->data['Karciskeluar']['jumlahlembarbaru'])) {
				if ($this->data['Karciskeluar']['jumlahlembarbaru'] > 0) {
					// ambil data stok karcisnya dulu
					$this->Karciskeluar->Karcismasuk->recursive = -1;
					$masuk = $this->Karciskeluar->Karcismasuk->read(null,$this->data['Karciskeluar']['karcismasuk_id']);
					$stok = $masuk['Karcismasuk']['stokkarcis'] + $this->data['Karciskeluar']['jumlahlembarlama'] - $this->data['Karciskeluar']['jumlahlembarbaru'];
					//debug($stok);
					if ($stok >= 0) {
						$masuk['Karcismasuk']['stokkarcis'] = $stok;
						if ($this->data['Karciskeluar']['jumlahlembarlama']==$this->data['Karciskeluar']['karcisblmdisetor']) {
							$this->data['Karciskeluar']['jumlahlembar'] = $this->data['Karciskeluar']['jumlahlembarbaru'];
							$this->data['Karciskeluar']['karcisblmdisetor'] = $this->data['Karciskeluar']['jumlahlembar'];
						} else {
							$selisih = $this->data['Karciskeluar']['jumlahlembarlama'] - $this->data['Karciskeluar']['karcisblmdisetor'];
							if ($selisih < $this->data['Karciskeluar']['jumlahlembarbaru']) {
								$this->data['Karciskeluar']['jumlahlembar'] = $this->data['Karciskeluar']['jumlahlembarbaru'];
								$this->data['Karciskeluar']['karcisblmdisetor'] = $this->data['Karciskeluar']['karcisblmdisetor'] - ($this->data['Karciskeluar']['jumlahlembarlama'] - $this->data['Karciskeluar']['jumlahlembarbaru']);
							} else if ($selisih == $this->data['Karciskeluar']['jumlahlembarbaru']) {
								$this->data['Karciskeluar']['jumlahlembar'] = $this->data['Karciskeluar']['jumlahlembarbaru'];
								$this->data['Karciskeluar']['karcisblmdisetor'] = 0;
							} else if ($selisih > $this->data['Karciskeluar']['jumlahlembarbaru']) {
								$this->Session->setFlash(__('Jumlah Pengambilan Karcis yang BARU minimal '.$selisih.' lembar', true),'default',array('class'=>'error-message'));
								$jmllbr = $this->data['Karciskeluar']['jumlahlembar'];
								$karcismasuk = $this->Karciskeluar->Karcismasuk->find('list',array('conditions'=>array('id'=>$this->data['Karciskeluar']['karcismasuk_id'])));
								$pemungut = $this->Karciskeluar->Pemungut->find('list',array('order'=>array('Pemungut.nama'=>'asc')));
								$this->set(compact('karcismasuk', 'pemungut', 'jmllbr'));
								return;
							}
						}
					} else {
						$stokmax = $masuk['Karcismasuk']['stokkarcis'] + $this->data['Karciskeluar']['jumlahlembarlama'];
						$this->Session->setFlash(__('Jumlah Stok Karcis tidak mencukupi (pengambilan maksimal '.$stokmax.' lembar)', true),'default',array('class'=>'error-message'));
						$jmllbr = $this->data['Karciskeluar']['jumlahlembar'];
						$karcismasuk = $this->Karciskeluar->Karcismasuk->find('list',array('conditions'=>array('id'=>$this->data['Karciskeluar']['karcismasuk_id'])));
						$pemungut = $this->Karciskeluar->Pemungut->find('list',array('order'=>array('Pemungut.nama'=>'asc')));
						$this->set(compact('karcismasuk', 'pemungut', 'jmllbr'));
						return;
					}
				}
				$this->data['Karciskeluar']['nilairupiah'] = $this->data['Karciskeluar']['nilaiperlembar'] *$this->data['Karciskeluar']['jumlahlembar'];
			}
			//debug($this->data);debug($masuk);exit;
			if ($this->Karciskeluar->save($this->data)) {
				if (!empty($masuk)) $this->Karciskeluar->Karcismasuk->save($masuk);
				$this->Session->setFlash(__('Data telah diubah', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Karciskeluar->read(null, $id);
			if (empty($this->data)) {
				$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
				$this->redirect(array('action' => 'index'));
			}
		}
		$jmllbr = $this->data['Karciskeluar']['jumlahlembar'];
		$karcismasuk = $this->Karciskeluar->Karcismasuk->find('list',array('conditions'=>array('id'=>$this->data['Karcismasuk']['id'])));
		$pemungut = $this->Karciskeluar->Pemungut->find('list',array('order'=>array('Pemungut.nama'=>'asc')));
		$this->set(compact('karcismasuk', 'pemungut', 'jmllbr'));
	}
	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$karciskeluar = $this->Karciskeluar->read(null, $id);
		if (empty($karciskeluar)) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('karciskeluar', $karciskeluar);
	}
	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		$data = $this->Karciskeluar->read(null, $id);
		if (empty($data)) {
			$this->Session->setFlash(__('Data yang akan dihapus tidak ditemukan', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		if ($data['Setorkarcis']!=null) {
			$this->Session->setFlash(__('Data tidak dapat dihapus karena sudah ada setoran untuk distribusi karcis ini.', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		$jmlstok = $data['Karciskeluar']['jumlahlembar'];
		$masuk['Karcismasuk'] = $data['Karcismasuk'];
		$masuk['Karcismasuk']['stokkarcis'] = $masuk['Karcismasuk']['stokkarcis'] + $jmlstok;
		if ($this->Karciskeluar->delete($id)) {
			$this->Karciskeluar->Karcismasuk->save($masuk);
			$this->Session->setFlash(__('Data telah dihapus', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Data tidak dapat dihapus', true),'default',array('class'=>'error-message'));
		$this->redirect(array('action' => 'index'));
	}
	function cetaktandaterima($id = null){
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		$data = $this->Karciskeluar->read(null,$id);
		$pejabat = $this->Pejabat->read(null,3);
		//debug($data); debug($pejabat); exit;
		$terbilang = $this->terbilang($data['Karciskeluar']['nilairupiah'],3);
		Configure::write('debug',0);
        $this->layout = 'pdf';
        $this->set(compact('data','pejabat','terbilang'));
        $this->render();
	}
}
?>