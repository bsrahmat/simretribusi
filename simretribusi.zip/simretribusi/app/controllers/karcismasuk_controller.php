<?php
class KarcismasukController extends AppController {
	var $name = 'Karcismasuk';

	function index() {
		$this->Karcismasuk->recursive = 0;
		$this->paginate = array('Karcismasuk'=>  array('limit'=>30, 'order'=>array('Karcismasuk.tanggal'=>'desc')));
		$this->set('karcismasuk', $this->paginate('Karcismasuk'));
	}
	function add() {
		if (!empty($this->data)) {
			$this->data['Karcismasuk']['nilairupiah'] = $this->data['Karcismasuk']['nilaiperlembar'] * $this->data['Karcismasuk']['jumlahlembar'];
			$this->data['Karcismasuk']['stokkarcis'] = $this->data['Karcismasuk']['jumlahlembar'];
			$this->Karcismasuk->create();
			if ($this->Karcismasuk->save($this->data)) {
				$this->Session->setFlash(__('Data telah disimpan', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
	}
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$this->data['Karcismasuk']['nilairupiah'] = $this->data['Karcismasuk']['nilaiperlembar'] * $this->data['Karcismasuk']['jumlahlembar'];
			if (!empty($this->data['Karcismasuk']['stokkarcisbaru'])){
				if ($this->data['Karcismasuk']['stokkarcisbaru'] < 0) $this->data['Karcismasuk']['stokkarcis'] = 0;
				else if ($this->data['Karcismasuk']['stokkarcisbaru'] > $this->data['Karcismasuk']['jumlahlembar'])
					$this->data['Karcismasuk']['stokkarcis'] = $this->data['Karcismasuk']['jumlahlembar'];
				else $this->data['Karcismasuk']['stokkarcis'] = $this->data['Karcismasuk']['stokkarcisbaru'];
			} else if ($this->data['Karcismasuk']['stokkarcisbaru']==0) $this->data['Karcismasuk']['stokkarcis'] = 0;
			//debug($this->data);exit;
			if ($this->Karcismasuk->save($this->data)) {
				$this->Session->setFlash(__('Data telah diubah', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Karcismasuk->read(null, $id);
			$stok = $this->data['Karcismasuk']['stokkarcis'];
			$this->set(compact('stok'));
		}
	}
	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('karcismasuk', $this->Karcismasuk->read(null, $id));
	}
	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		$this->Karcismasuk->recursive = -1;
		$data = $this->Karcismasuk->read(null, $id);
		if (empty($data)) {
			$this->Session->setFlash(__('Data yang akan dihapus tidak ditemukan', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		if ($data['Karcismasuk']['jumlahlembar'] != $data['Karcismasuk']['stokkarcis']) {
			$this->Session->setFlash(__('Data tidak dapat dihapus karena karcis sudah didistribusikan (sudah ada yang diambil oleh Pemungut)', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Karcismasuk->delete($id)) {
			$this->Session->setFlash(__('Data telah dihapus', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Data tidak dapat dihapus', true),'default',array('class'=>'error-message'));
		$this->redirect(array('action' => 'index'));
	}
	function stok(){
		$this->Karcismasuk->recursive = 0;
		$karcismasuk = $this->Karcismasuk->find('all',array('conditions'=>array('stokkarcis >'=>'0'), 'order'=>array('Karcismasuk.tanggal'=>'desc')));
		$this->set('karcismasuk', $karcismasuk);
	}
}
?>