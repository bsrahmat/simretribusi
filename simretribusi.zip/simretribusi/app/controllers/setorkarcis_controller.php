<?php
class SetorkarcisController extends AppController {
	var $name = 'Setorkarcis';

	function index() {
		$this->Setorkarcis->recursive = 0;
		$this->paginate = array('Setorkarcis'=>  array('limit'=>40,
						'order'=>array('Setorkarcis.tanggal'=>'desc')));
		$this->set('setorkarcis', $this->paginate('Setorkarcis'));
	}
	function add() {
		if (!empty($this->data)) {
			// Kurangi jumlah karcis yang belum disetor dengan banyaknya lembar
			$this->Setorkarcis->Karciskeluar->recursive = -1;
			$karciskeluar = $this->Setorkarcis->Karciskeluar->read(null,$this->data['Setorkarcis']['karciskeluar_id']);
			if (($this->data['Setorkarcis']['jumlahlembar'] > $karciskeluar['Karciskeluar']['karcisblmdisetor']) || $this->data['Setorkarcis']['jumlahlembar']==0) {
				$this->Session->setFlash(__('Jumlah lembar karcis yang disetor lebih banyak dari jumlah pengambilan karcis.', true),'default',array('class'=>'error-message'));
				$this->redirect(array('action' => 'index'));
			}
			$this->Setorkarcis->create();
			if ($this->Setorkarcis->save($this->data)) {
				$karciskeluar['Karciskeluar']['karcisblmdisetor'] = $karciskeluar['Karciskeluar']['karcisblmdisetor'] - $this->data['Setorkarcis']['jumlahlembar'];
				$this->Setorkarcis->Karciskeluar->save($karciskeluar);
				$this->Session->setFlash(__('Data telah disimpan', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
		$karcis = $this->Setorkarcis->Karciskeluar->find('list',array('conditions'=>array('karcisblmdisetor >'=>'0'),'order'=>array('Karciskeluar.tanggal'=>'asc')));
		if (empty($karcis)){
			$this->Session->setFlash(__('Tidak ada karcis yang akan disetor. Semua sudah ada Laporan Pemungutan dan Penyetoran (LPP). Silahkan Input Distribusi Karcis dahulu.', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$karciskeluar = $this->Setorkarcis->Karciskeluar->find('list');
		$this->set(compact('karciskeluar'));
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true));
			$this->redirect(array('action' => 'index'));
		}
		$setorkarcis = $this->Setorkarcis->read(null, $id);
		if (empty($setorkarcis)) {
			$this->Session->setFlash(__('Invalid data', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set(compact('setorkarcis'));
	}


	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid data', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$this->Setorkarcis->Karciskeluar->recursive = -1;
			$karciskeluar = $this->Setorkarcis->Karciskeluar->read(null,$this->data['Setorkarcis']['karciskeluar_id']);
			$jmlstok = $this->data['Setorkarcis']['jumlahlembar'] + $karciskeluar['Karciskeluar']['karcisblmdisetor'];
			if (($this->data['Setorkarcis']['jumlahlembarbaru'] > $jmlstok) || $this->data['Setorkarcis']['jumlahlembarbaru']==0) {
				$this->Session->setFlash(__('Jumlah lembar karcis yang disetor lebih banyak dari jumlah pengambilan karcis.', true),'default',array('class'=>'error-message'));
				$this->redirect(array('action' => 'index'));
			}
			$this->data['Setorkarcis']['jumlahlembar'] = $this->data['Setorkarcis']['jumlahlembarbaru'];
			if ($this->Setorkarcis->save($this->data)) {
				$karciskeluar['Karciskeluar']['karcisblmdisetor'] = $jmlstok - $this->data['Setorkarcis']['jumlahlembarbaru'];
				$this->Setorkarcis->Karciskeluar->save($karciskeluar);

				$this->Session->setFlash(__('Data telah disimpan', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Setorkarcis->read(null, $id);
		}
		$karciskeluar = $this->Setorkarcis->Karciskeluar->find('list');
		$this->set(compact('karciskeluar'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		$this->Setorkarcis->recursive = -1;
		$data = $this->Setorkarcis->read(null, $id);
		if (empty($data)) {
			$this->Session->setFlash(__('Data yang akan dihapus tidak ditemukan', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		$this->Setorkarcis->Karciskeluar->recursive = -1;
		$karciskeluar = $this->Setorkarcis->Karciskeluar->read(null,$data['Setorkarcis']['karciskeluar_id']);
		$karciskeluar['Karciskeluar']['karcisblmdisetor'] = $karciskeluar['Karciskeluar']['karcisblmdisetor'] + $data['Setorkarcis']['jumlahlembar'];
		if ($this->Setorkarcis->delete($id)) {
			$this->Setorkarcis->Karciskeluar->save($karciskeluar);
			$this->Session->setFlash(__('Data telah dihapus', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Data tidak dapat dihapus', true),'default',array('class'=>'error-message'));
		$this->redirect(array('action' => 'index'));
	}
	function cetaklpp($id=null){
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$data = $this->Setorkarcis->read(null,$id);
		//debug($data); exit;
		$terbilang = $this->terbilang($data['Setorkarcis']['jumlahrupiah'],3);
		Configure::write('debug',0);
        $this->layout = 'pdf';
        $this->set(compact('data','terbilang'));
        $this->render();
	}
}
?>