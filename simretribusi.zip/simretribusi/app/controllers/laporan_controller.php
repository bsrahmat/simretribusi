<?php
/*
 * Created by Yelly Abu Zaid on Nov 29, 2010
 * Support : addibomo@gmail.com
 *  YM! ID : adi_bomo
 * Copyright @2010 Yelly Abu Zaid Damopolii
 */

class LaporanController extends AppController {
	var $name = 'Laporan';
	var $uses = array('Kecamatan','Karciskeluar','Skrd','Perusahaan','Bank','Target','Pejabat','Bayarretribusi','Setorkarcis','Vrekap');

	function pilih($idpilih=null){
		if ($idpilih==1) {
			$judul = 'Buku Pembantu Per Rincian Objek (SKRD)';
		} else if ($idpilih==2) {
			$judul = 'Buku Pembantu Per Rincian Objek (Karcis)';
		} else if ($idpilih==3) {
			$judul = 'Rekapitulasi Penerimaan Retribusi Kebersihan';
		} else {
			$judul = 'Laporan Tunggakan Perusahaan';
			$idpilih = 4;
		}
		$kecamatan = $this->Kecamatan->find('list',array('order'=>array('nama'=>'asc')));
		$this->set(compact('kecamatan','judul','idpilih'));
	}
	function prosespilih(){
		if (empty($this->data)) {
			$this->redirect(array('action' => 'pilih'));
		}
		//debug($this->data);exit;
		$tahun = $this->data['Laporan']['tahun']['year'];
		$kec = $this->data['Laporan']['kecamatan_id'];
		$idpilih = $this->data['Laporan']['idn'];
		if ($idpilih==1) {
			$bln = $this->data['Laporan']['tahun']['month'];
			$this->redirect(array('action' => 'bpskrd', $tahun, $bln));
		} else if ($idpilih==2) {
			$bln = $this->data['Laporan']['tahun']['month'];
			$this->redirect(array('action' => 'bpkarcis', $tahun, $bln));
		} else if ($idpilih==3) {
			$bln = $this->data['Laporan']['tahun']['month'];
			$this->redirect(array('action' => 'rekappenerimaan', $tahun, $bln));
		} else {
			$this->redirect(array('action' => 'tunggakanperusahaan', $tahun, $kec));
			$idpilih = 4;
		}
	}
	function tunggakankarcis(){
		$this->Karciskeluar->recursive = -1;
		$data = $this->Karciskeluar->find('all',array(
						'conditions'=>array('karcisblmdisetor >'=>'0'),
						'order'=>array('pemungut_nama'=>'asc')
					));
		//debug($data);
		$this->set(compact('data'));
	}
	function tunggakanperusahaan($tahun=null,$idkec=null){
		if ($tahun==null && $idkec==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '4'));
		}
		if ($idkec==null) {
			// untuk seluruh kecamatan
			$kecamatan = 'Seluruh Kecamatan';
			$data = $this->Skrd->find('all',array(
							'conditions'=>array('tahun'=>$tahun,'belumdibayar >'=>'0'),
							'order'=>array('Perusahaan.nama'=>'asc')
						));
		} else {
			$tmp = $this->Kecamatan->read(null,$idkec);
			$kecamatan = $tmp['Kecamatan']['nama'];
			$data = $this->Perusahaan->find('all',array(
							'contain'=>array('Skrd.tahun='.$tahun,'Skrd.belumdibayar > 0'),
							'conditions'=>array('kecamatan_id'=>$idkec),
							'order'=>array('Perusahaan.nama'=>'asc')
						));
		}
		$this->set(compact('data','tahun','kecamatan','idkec'));
	}
	function bpskrd($tahun=null,$bln=null){
		if ($tahun==null || $bln==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '1'));
		}
		//
		$bank = $this->Bank->find('first');
		$target = $this->Target->find('first',array('conditions'=>array('tahun'=>$tahun)));
		$pejabat = $this->Pejabat->read(null,2);
		$datalama = $this->Bayarretribusi->query("SELECT sum(jumlahbayar) as Total FROM bayarretribusi where MONTH(tanggal)<".$bln." and YEAR(tanggal)=".$tahun);
		$jmlblnlalu = $datalama[0][0]['Total'];
		$data = $this->Bayarretribusi->find('all',array(
					'conditions'=>array('MONTH(tanggal)'=>$bln, 'YEAR(tanggal)'=>$tahun),
				));
		//debug($datalama); debug($jmlblnlalu);
		//debug($data);exit;
		$this->set(compact('bank','target','pejabat','jmlblnlalu','data','tahun','bln'));
	}
	function cetakbpskrd($tahun=null, $bln=null){
		if ($tahun==null || $bln==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '1'));
		}
		//
		$bank = $this->Bank->find('first');
		$target = $this->Target->find('first',array('conditions'=>array('tahun'=>$tahun)));
		$pejabat = $this->Pejabat->read(null,2);
		$tglakhir = $this->tglakhir($bln);
		//debug($pejabat);exit;
		$datalama = $this->Bayarretribusi->query("SELECT sum(jumlahbayar) as Total FROM bayarretribusi where MONTH(tanggal)<".$bln." and YEAR(tanggal)=".$tahun);
		$jmlblnlalu = $datalama[0][0]['Total'];
		$data = $this->Bayarretribusi->find('all',array(
					'conditions'=>array('MONTH(tanggal)'=>$bln, 'YEAR(tanggal)'=>$tahun),
				));
		Configure::write('debug',0);
        $this->layout = 'pdf';
		$this->set(compact('bank','target','pejabat','jmlblnlalu','data','tahun','bln','tglakhir'));
        $this->render();
	}
	function bpkarcis($tahun=null,$bln=null){
		if ($tahun==null && $bln==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '2'));
		}
		$bank = $this->Bank->find('first');
		$target = $this->Target->find('first',array('conditions'=>array('tahun'=>$tahun)));
		$pejabat = $this->Pejabat->read(null,2);
		$tglakhir = $this->tglakhir($bln);
		$datalama = $this->Setorkarcis->query("SELECT sum(jumlahrupiah) as Total FROM setorkarcis where MONTH(setorkarcis.tanggal)<".$bln." and YEAR(setorkarcis.tanggal)=".$tahun);
		$jmlblnlalu = $datalama[0][0]['Total'];
		$data = $this->Setorkarcis->find('all',array(
					'conditions'=>array('MONTH(Setorkarcis.tanggal)'=>$bln, 'YEAR(Setorkarcis.tanggal)'=>$tahun),
				));
		$this->set(compact('bank','target','pejabat','jmlblnlalu','data','tahun','bln','tglakhir'));
	}
	function cetakbpkarcis($tahun=null,$bln=null){
		if ($tahun==null && $bln==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '2'));
		}
		$bank = $this->Bank->find('first');
		$target = $this->Target->find('first',array('conditions'=>array('tahun'=>$tahun)));
		$pejabat = $this->Pejabat->read(null,2);
		$tglakhir = $this->tglakhir($bln);
		//data
		$datalama = $this->Setorkarcis->query("SELECT sum(jumlahrupiah) as Total FROM setorkarcis where MONTH(setorkarcis.tanggal)<".$bln." and YEAR(setorkarcis.tanggal)=".$tahun);
		$jmlblnlalu = $datalama[0][0]['Total'];
		$data = $this->Setorkarcis->find('all',array(
					'conditions'=>array('MONTH(Setorkarcis.tanggal)'=>$bln, 'YEAR(Setorkarcis.tanggal)'=>$tahun),
				));
		//debug($datalama); debug($jmlblnlalu);
		//debug($data);exit;
		Configure::write('debug',0);
        $this->layout = 'pdf';
		$this->set(compact('bank','target','pejabat','jmlblnlalu','data','tahun','bln','tglakhir'));
        $this->render();
	}
	function rekappenerimaan($tahun=null,$bln=null){
		if ($tahun==null && $bln==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '3'));
		}
		$pejabat = $this->Pejabat->read(null,2);
		$tglakhir = $this->tglakhir($bln);
		$datalama = $this->Vrekap->query("SELECT sum(jumlahbayar) as Total FROM vrekap where MONTH(vrekap.tanggal)<".$bln." and YEAR(vrekap.tanggal)=".$tahun);
		$jmlblnlalu = $datalama[0][0]['Total'];
		$data = $this->Vrekap->find('all',array(
					'conditions'=>array('MONTH(Vrekap.tanggal)'=>$bln, 'YEAR(Vrekap.tanggal)'=>$tahun),
					'order'=>array('tanggal'=>'asc'),
				));
		//debug($datalama); debug($jmlblnlalu);
		//debug($data);exit;
		Configure::write('debug',0);
        $this->layout = 'pdf';
		$this->set(compact('pejabat','jmlblnlalu','data','tahun','bln','tglakhir'));
        $this->render();
	}
	function tglakhir($bln){
		$tgl = 0;
		switch ($bln) {
			case 1 : $tgl = 31;
			case 2 : $tgl = 28;
			case 3 : $tgl = 31;
			case 4 : $tgl = 30;
			case 5 : $tgl = 31;
			case 6 : $tgl = 30;
			case 7 : $tgl = 31;
			case 8 : $tgl = 31;
			case 9 : $tgl = 30;
			case 10 : $tgl = 31;
			case 11 : $tgl = 30;
			case 12 : $tgl = 31;
		}
		return $tgl;
	}
}
?>
