<?php
class BayarretribusiController extends AppController {
	var $name = 'Bayarretribusi';
	var $uses = array('Bayarretribusi','Kecamatan','Perusahaan','Bank','Pejabat');

	function pilih(){
		$kecamatan = $this->Kecamatan->find('list',array('order'=>array('nama'=>'asc')));
		$this->set(compact('kecamatan'));
	}
	function prosespilih(){
		if (!empty($this->data)) {
			$tahun = $this->data['Bayarretribusi']['tahun']['year'];
			$kec = $this->data['Bayarretribusi']['kecamatan_id'];
			$this->redirect(array('action' => 'index', $tahun, $kec));
		} else $this->redirect(array('action' => 'pilih'));
	}
	function index($tahun=null,$kec=null) {
		if (empty($tahun)) {
			$this->Session->setFlash(__('Silahkan pilih dahulu Tahun Pembayaran dan Kecamatan dimana Perusahaan berada', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih'));
		}
		if (!empty($kec)) {
			$this->Kecamatan->recursive = -1;
			$tmp= $this->Kecamatan->read(null,$kec);
			$kecamatan = 'Kecamatan '.$tmp['Kecamatan']['nama'];
			$this->paginate = array('Perusahaan'=>  array('limit'=>20,'contain'=>array('Skrd.tahun='.$tahun,'Skrd.Bayarretribusi'),
						'fields'=>array('Perusahaan.id','Perusahaan.nama','Perusahaan.alamat'),
						'conditions'=>array('Perusahaan.kecamatan_id'=>$kec),
						'order'=>array('Perusahaan.nama'=>'asc')),
					);
		} else {
			$kecamatan = 'Seluruh Kecamatan';
			$this->paginate = array('Perusahaan'=>  array('limit'=>40,'contain'=>array('Kecamatan.nama','Skrd.tahun='.$tahun,'Skrd.Bayarretribusi'),
					'fields'=>array('Perusahaan.id','Perusahaan.nama','Perusahaan.alamat'),
					'order'=>array('Kecamatan.nama'=>'asc','Perusahaan.nama'=>'asc')));
		}
		$bayarretribusi = $this->paginate('Perusahaan');
		//debug($bayarretribusi); exit;
		$this->set(compact('bayarretribusi','kecamatan','tahun','kec'));
	}
	function add($idskrd=null) {
		if (!empty($this->data)) {
			$link = $this->data['Bayarretribusi']['backlink'];
			$skrd = $this->Bayarretribusi->Skrd->read(null,$this->data['Bayarretribusi']['skrd_id']);
			$kurangbayar = $skrd['Skrd']['belumdibayar'];
			//debug($this->data); debug($skrd); exit;
			if ($this->data['Bayarretribusi']['jumlahbayar']>$kurangbayar || $kurangbayar==0) {
				$this->set(compact('skrd','link'));
				$this->Session->setFlash(__('Jumlah Pembayaran melebihi jumlah yang harus dibayar.', true),'default',array('class'=>'error-message'));
				return;
			} else {
				$this->Bayarretribusi->create();
				if ($this->Bayarretribusi->save($this->data)) {
					$skrd['Skrd']['belumdibayar'] = $kurangbayar - $this->data['Bayarretribusi']['jumlahbayar'];
					$this->Bayarretribusi->Skrd->save($skrd);
					$this->Session->setFlash(__('Data telah disimpan', true));
					$this->redirect($link);
				} else {
					$this->set(compact('skrd','link'));
					$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
				}
			}
		} else if ($idskrd==null) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih'));
		} else {
			$skrd = $this->Bayarretribusi->Skrd->read(null,$idskrd);
			if (empty($skrd)) {
				$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
				$this->redirect(array('action' => 'pilih'));
			}
			$link = $this->backlink();
			$this->set(compact('skrd','link'));
		}
	}
	function edit($idbayarretribusi = null) {
		if (!$idbayarretribusi && empty($this->data)) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih'));
		}
		if (!empty($this->data)) {
			$link = $this->data['Bayarretribusi']['backlink'];
			$skrd = $this->Bayarretribusi->Skrd->read(null,$this->data['Bayarretribusi']['skrd_id']);
			$jmlbayarlama = $this->data['Bayarretribusi']['jumlahbayarlama'];
			$kurangbayar = $skrd['Skrd']['belumdibayar'] + $jmlbayarlama;
			//debug($this->data); debug($skrd); exit;
			if ($this->data['Bayarretribusi']['jumlahbayar']>$kurangbayar) {
				$this->set(compact('skrd','link','jmlbayarlama'));
				$this->Session->setFlash(__('Jumlah Pembayaran melebihi jumlah yang harus dibayar', true),'default',array('class'=>'error-message'));
				return;
			} else {
				if ($this->Bayarretribusi->save($this->data)) {
					$skrd['Skrd']['belumdibayar'] = $kurangbayar - $this->data['Bayarretribusi']['jumlahbayar'];
					$this->Bayarretribusi->Skrd->save($skrd);
					$this->Session->setFlash(__('Data telah diubah', true));
					$this->redirect($link);
				} else {
					$this->set(compact('skrd','link','jmlbayarlama'));
					$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
				}
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Bayarretribusi->read(null, $idbayarretribusi);
			if (empty($this->data)) {
				$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
				$this->redirect(array('action' => 'pilih'));
			}
		}
		$skrd = $this->Bayarretribusi->Skrd->read(null,$this->data['Bayarretribusi']['skrd_id']);
		$jmlbayarlama = $this->data['Bayarretribusi']['jumlahbayar'];
		$link = $this->backlink();
		$this->set(compact('skrd','link','jmlbayarlama'));
	}
	function view($idskrd = null) {
		if (!$idskrd) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih'));
		}
		//debug($link);
		$skrd = $this->Bayarretribusi->Skrd->find('first',array('contain'=>array('Perusahaan',
							'Bayarretribusi'=>array('order'=>array('Bayarretribusi.tanggal'=>'asc'))),
							'conditions'=>array('Skrd.id'=>$idskrd),
						));
		$link = $this->backlink();
		$hasil = strpos($link, 'retribusi/bayarretribusi/index/2');
		if($hasil){
			$ada=true;
		} else {
			$ada=false;
		}
		$this->set(compact('skrd','link','ada'));
	}
	function cetakstbp($idbayarretribusi=null){
		if (!$idbayarretribusi) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih'));
		}
		$data = $this->Bayarretribusi->find('first',array('contain'=>array('Skrd.Perusahaan'),
						'conditions'=>array('Bayarretribusi.id'=>$idbayarretribusi),
					));
		if (empty($data)) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih'));
		}
		$bank = $this->Bank->find('first');
		$pejabat = $this->Pejabat->find('first',array('conditions'=>array('id'=>'2')));
		//debug($perusahaan);debug($perda);debug($pejabat);exit;
		$terbilang = $this->terbilang($data['Bayarretribusi']['jumlahbayar'],3);
		//debug($data); exit;
		Configure::write('debug',0);
        $this->layout = 'pdf';
        $this->set(compact('data','bank','pejabat','terbilang'));
        $this->render();
	}

/*
	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for bayarretribusi', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Bayarretribusi->delete($id)) {
			$this->Session->setFlash(__('Bayarretribusi deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Bayarretribusi was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
*/
}
?>