<?php
class WelcomeController extends AppController {
	var $name = 'Welcome';
	var $uses = array();

	function index() {}

}
?>