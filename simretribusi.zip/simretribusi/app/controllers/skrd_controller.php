<?php
class SkrdController extends AppController {
	var $name = 'Skrd';
	var $uses = array('Skrd','Kecamatan','Perda','Pejabat','Bank');

	function pilih($pilihan){
		if ($pilihan==1) {
			$judul = 'Input Ketetapan Retribusi';
		} else if ($pilihan==3) {
			$judul = 'Cetak SKRD';
		} else {
			$pilihan = 2;
			$judul = 'Daftar Wajib Retribusi';
		}
		$kecamatan = $this->Kecamatan->find('list',array('order'=>array('nama'=>'asc')));
		$this->set(compact('judul','pilihan','kecamatan'));
	}
	function prosespilih(){
		if (!empty($this->data)) {
			$pilih = $this->data['Skrd']['idn']; // menentukan Menu Navigasi-nya
			$tahun = $this->data['Skrd']['tahun']['year'];
			$kec = $this->data['Skrd']['kecamatan_id'];
			$this->redirect(array('action' => 'index', $pilih, $tahun, $kec));
		} else $this->redirect(array('action' => 'pilih', '2'));
	}
	function index($pilih=null,$tahun=null,$kec=null) {
		if (!empty($pilih) && !empty($tahun)) {
			if ($pilih==1) {
				$judul = 'Input Ketetapan Retribusi';
			} else if ($pilih==3) {
				$judul = 'Cetak SKRD dan Surat Pengantar';
			} else {
				$judul = 'Daftar Wajib Retribusi';
			}
			if (!empty($kec)) {
				$this->Kecamatan->recursive = -1;
				$tmp= $this->Kecamatan->read(null,$kec);
				$kecamatan = 'Kecamatan '.$tmp['Kecamatan']['nama'];
				$this->paginate = array('Perusahaan'=>  array('limit'=>20,'contain'=>array('Skrd.tahun='.$tahun),
							//'fields'=>array('id','nama','alamat','telp','kecamatan_id','Kecamatan.nama'),
							'conditions'=>array('Perusahaan.kecamatan_id'=>$kec),
							'order'=>array('Perusahaan.nama'=>'asc')),
						);
			} else {
				$kecamatan = 'Seluruh Kecamatan';
				$this->paginate = array('Perusahaan'=>  array('limit'=>40,'contain'=>array('Kecamatan','Skrd.tahun='.$tahun),
						//'fields'=>array('id','nama','alamat','telp','kecamatan_id','Kecamatan.nama'),
						'order'=>array('Kecamatan.nama'=>'asc','Perusahaan.nama'=>'asc')));
			}
			$skrd = $this->paginate('Perusahaan');
			$this->set(compact('skrd','pilih','tahun','kecamatan','kec','judul'));
		} else $this->redirect(array('action' => 'pilih', '2'));
	}
	function view($id = null, $tahun=null) {
		if ($id==null || $tahun==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '2'));
		}
		$skrd = $this->Skrd->Perusahaan->find('first',array('order'=>array('Perusahaan.nama'=>'asc'),
									'contain'=>array('Kecamatan','Skrd.tahun='.$tahun),
									'conditions'=>array('Perusahaan.id'=>$id),
									));
		$this->set(compact('skrd','tahun'));
	}
	function add($id = null, $tahun=null) {
		if (!empty($this->data)) {
			$backlink = $this->data['Skrd']['backlink'];
			if (!empty($this->data['Skrd']['nilaiperbulan']))
				$this->data['Skrd']['nilaipertahun']=$this->data['Skrd']['nilaiperbulan']*12;
			else
				$this->data['Skrd']['nilaiperbulan']=$this->data['Skrd']['nilaipertahun']/12;
			$this->data['Skrd']['belumdibayar']=$this->data['Skrd']['nilaipertahun'];
			$this->Skrd->create();
			if ($this->Skrd->save($this->data)) {
				$this->Session->setFlash(__('Data telah disimpan', true));
				$this->redirect($backlink);
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		} else if ($id==null || $tahun==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '1'));
		}
		$link = $this->backlink();
		$perusahaan = $this->Skrd->Perusahaan->find('first',array('order'=>array('Perusahaan.nama'=>'asc'),
									'contain'=>array('Kecamatan','Skrd.tahun='.$tahun),
									'conditions'=>array('Perusahaan.id'=>$id),
									));
		//debug($perusahaan);
		$this->set(compact('perusahaan','link','tahun'));
	}
	function edit($id = null, $tahun=null) {
		if (!$id && !$tahun && empty($this->data)) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			$backlink = $this->data['Skrd']['backlink'];
			if (!empty($this->data['Skrd']['nilaiperbulanbaru'])) {
				$this->data['Skrd']['nilaipertahunbaru']=$this->data['Skrd']['nilaiperbulanbaru']*12;
				$this->data['Skrd']['nilaipertahun']=$this->data['Skrd']['nilaipertahunbaru'];
				$this->data['Skrd']['nilaiperbulan']=$this->data['Skrd']['nilaiperbulanbaru'];
				$this->data['Skrd']['belumdibayar']=$this->data['Skrd']['nilaipertahun'];
			} else if (!empty($this->data['Skrd']['nilaipertahunbaru'])) {
				$this->data['Skrd']['nilaiperbulanbaru']=$this->data['Skrd']['nilaipertahunbaru']/12;
				$this->data['Skrd']['nilaipertahun']=$this->data['Skrd']['nilaipertahunbaru'];
				$this->data['Skrd']['nilaiperbulan']=$this->data['Skrd']['nilaiperbulanbaru'];
				$this->data['Skrd']['belumdibayar']=$this->data['Skrd']['nilaipertahun'];
			}
			if ($this->Skrd->save($this->data)) {
				$this->Session->setFlash(__('Data telah diubah', true));
				$this->redirect($backlink);
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		} else if ($id==null || $tahun==null) {
			$this->Session->setFlash(__('Invalid Data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'pilih', '1'));
		}
		$link = $this->backlink();
		$perusahaan = $this->Skrd->Perusahaan->find('first',array('order'=>array('Perusahaan.nama'=>'asc'),
									'contain'=>array('Kecamatan','Skrd.tahun='.$tahun),
									'conditions'=>array('Perusahaan.id'=>$id),
									));
		$this->set(compact('perusahaan','link','tahun'));
	}
	function saveaspdf(){
		if (!empty($this->data)) {
			$tahun = $this->data['Skrd']['tahun'];
			$idkecamatan = $this->data['Skrd']['idkec'];
			if (!empty($idkecamatan)) {
				$this->Kecamatan->recursive = -1;
				$tmp= $this->Kecamatan->read(null,$idkecamatan);
				$kecamatan = $tmp['Kecamatan']['nama'];
				$perusahaan = $this->Skrd->Perusahaan->find('all', array('limit'=>20,'contain'=>array('Skrd.tahun='.$tahun),
								'conditions'=>array('Perusahaan.kecamatan_id'=>$idkecamatan),
								'order'=>array('Perusahaan.nama'=>'asc')
							));
			} else {
				$kecamatan = 'Seluruh Kecamatan';
				$perusahaan = $this->Skrd->Perusahaan->find('all', array('limit'=>40,'contain'=>array('Kecamatan','Skrd.tahun='.$tahun),
						'order'=>array('Kecamatan.nama'=>'asc','Perusahaan.nama'=>'asc')));
			}
			$namafile = $tahun.'-'.$kecamatan.'-Daftar_Retribusi_Perusahaan';
			$namafile = str_replace(' ','_',$namafile);
			Configure::write('debug',0);
	        $this->layout = 'pdf';
	        $this->set(compact('perusahaan','idkecamatan','tahun','kecamatan','namafile'));
	        $this->render();
		} else $this->redirect(array('action' => 'pilih', '2'));
	}
	function cetaksurat($idp=null,$tahun=null){
		if (empty($idp) || empty($tahun))
			$this->redirect(array('action' => 'pilih', '3'));
		else {
			$perusahaan = $this->Skrd->Perusahaan->find('first',array('contain'=>array('Skrd.tahun='.$tahun),'conditions'=>array('Perusahaan.id'=>$idp)));
			$perda = $this->Perda->find('first');
			$pejabat = $this->Pejabat->find('first',array('conditions'=>array('id'=>'1')));
			//debug($perusahaan);debug($perda);debug($pejabat);exit;
			$terbilang = $this->terbilang($perusahaan['Skrd'][0]['nilaipertahun'],3);
			//-----------------
			Configure::write('debug',0);
	        $this->layout = 'pdf';
	        $this->set(compact('perusahaan','perda','pejabat','tahun','terbilang'));
	        $this->render();
		}
	}
	function cetakskrd($idp=null,$tahun=null){
		if (empty($idp) || empty($tahun))
			$this->redirect(array('action' => 'pilih', '3'));
		else {
			$perusahaan = $this->Skrd->Perusahaan->find('first',array('contain'=>array('Skrd.tahun='.$tahun),'conditions'=>array('Perusahaan.id'=>$idp)));
			$perda = $this->Perda->find('first');
			$bank = $this->Bank->find('first');
			$pejabat = $this->Pejabat->find('first',array('conditions'=>array('id'=>'1')));
			//debug($perusahaan);debug($perda);debug($bank);debug($pejabat);exit;
			$terbilang = $this->terbilang($perusahaan['Skrd'][0]['nilaipertahun'],3);
			Configure::write('debug',0);
	        $this->layout = 'pdf';
	        $this->set(compact('perusahaan','perda','bank','pejabat','tahun','terbilang'));
	        $this->render();
		}
	}
/*
	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for skrd', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Skrd->delete($id)) {
			$this->Session->setFlash(__('Skrd deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Skrd was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
*/
}
?>