<?php
class PerusahaanController extends AppController {
	var $name = 'Perusahaan';

	function index() {
		$this->Perusahaan->recursive = 0;
		$this->paginate = array('Perusahaan'=>  array('limit'=>20, 'fields'=>array('id','nama','alamat','telp','kecamatan_id','Kecamatan.nama'),
						'order'=>array('Perusahaan.nama'=>'asc')));
		$this->set('perusahaan', $this->paginate('Perusahaan'));
	}
	function add() {
		if (!empty($this->data)) {
			$this->Perusahaan->create();
			if ($this->Perusahaan->save($this->data)) {
				$this->Session->setFlash(__('Data telah disimpan', true));
				$this->redirect(array('action' => 'add'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
		$kecamatan = $this->Perusahaan->Kecamatan->find('list',array('order'=>array('nama'=>'asc')));
		$this->set(compact('kecamatan'));
	}
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Perusahaan->save($this->data)) {
				$this->Session->setFlash(__('Data telah diubah', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Perusahaan->read(null, $id);
		}
		$kecamatan = $this->Perusahaan->Kecamatan->find('list',array('order'=>array('nama'=>'asc')));
		$this->set(compact('kecamatan'));
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$perusahaan = $this->Perusahaan->read(null, $id);
		if ($perusahaan==null) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		$this->set(compact('perusahaan'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Perusahaan->delete($id)) {
			$this->Session->setFlash(__('Data telah dihapus', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Data tidak dapat dihapus', true),'default',array('class'=>'error-message'));
		$this->redirect(array('action' => 'index'));
	}
}
?>