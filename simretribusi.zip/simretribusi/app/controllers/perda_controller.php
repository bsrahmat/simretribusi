<?php
class PerdaController extends AppController {
	var $name = 'Perda';

	function index() {
		/*if (!empty($this->data)) {
			$this->Perda->create();
			if ($this->Perda->save($this->data)) {
				$this->Session->setFlash(__('Data telah disimpan', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true));
			}
		}*/
		$this->Perda->recursive = 0;
		$this->set('perda', $this->paginate());
	}
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Perda->save($this->data)) {
				$this->Session->setFlash(__('Data telah diubah', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Perda->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Perda->delete($id)) {
			$this->Session->setFlash(__('Data telah dihapus', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Data tidak dapat dihapus', true),'default',array('class'=>'error-message'));
		$this->redirect(array('action' => 'index'));
	}
}
?>