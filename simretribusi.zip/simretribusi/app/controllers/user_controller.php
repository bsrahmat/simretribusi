<?php
class UserController extends AppController {
	var $name = 'User';
	//var $components = array('Session');

	function beforeFilter(){
		parent::beforeFilter();
		//$this->Auth->allow('register');
	}
	function login(){}
	function logout(){
		$this->redirect($this->Auth->logout());
	}
	function register() {
	    if ($this->data) {
	        if ($this->data['User']['password'] == $this->Auth->password($this->data['User']['password_confirm'])) {
	        	//debug($this->data);exit;
	            $this->User->create();
	            if ($this->User->save($this->data)) {
					$this->Session->setFlash(__('Data Pengguna baru telah disimpan', true));
					$this->redirect(array('action' => 'register'));
	        	} else {
	        		$this->data['User']['password'] = '';
		        	$this->data['User']['password_confirm'] = '';
		        	$this->Session->setFlash(__('Data Pengguna gagal disimpan. Mohon lengkapi data yang diminta.', true),'default',array('class'=>'error-message'));
		        	return;
	        	}
	        } else {
	        	$this->data['User']['password'] = '';
	        	$this->data['User']['password_confirm'] = '';
	        	$this->Session->setFlash(__('Kata Sandi tidak sama. Mohon diketik ulang.', true),'default',array('class'=>'error-message'));
	        	return;
	        }
	    }
	}

	function index() {
		$this->User->recursive = 0;
		$this->paginate = array('User'=>array('order'=>array('username'=>'asc')));
		$this->set('user', $this->paginate('User'));
	}
	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if (!empty($this->data['User']['password_baru'])) {
		        if ($this->Auth->password($this->data['User']['password_baru']) == $this->Auth->password($this->data['User']['password_confirm'])) {
		        	$this->data['User']['password'] = $this->Auth->password($this->data['User']['password_baru']);
		            if ($this->User->save($this->data)) {
						$this->Session->setFlash(__('Data telah diubah', true));
						$this->redirect(array('action' => 'index'));
		        	} else {
		        		$this->data['User']['password_baru'] = '';
			        	$this->data['User']['password_confirm'] = '';
			        	$this->Session->setFlash(__('Data Pengguna gagal disimpan. Mohon lengkapi data yang diminta.', true),'default',array('class'=>'error-message'));
			        	return;
		        	}
		        } else {
		        	$this->data['User']['password_baru'] = '';
		        	$this->data['User']['password_confirm'] = '';
		        	$this->Session->setFlash(__('Kata Sandi tidak sama. Mohon diketik ulang.', true),'default',array('class'=>'error-message'));
		        	return;
		        }
			} else {
				if ($this->User->save($this->data)) {
					$this->Session->setFlash(__('Data telah diubah', true));
					$this->redirect(array('action' => 'index'));
				} else {
					$this->Session->setFlash(__('Data gagal disimpan. Coba ulangi lagi.', true),'default',array('class'=>'error-message'));
				}
			}
		}
		if (empty($this->data)) {
			$this->data = $this->User->read(null, $id);
			//debug($this->data);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid data', true),'default',array('class'=>'error-message'));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->User->delete($id)) {
			$this->Session->setFlash(__('Data telah dihapus', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Data tidak dapat dihapus', true),'default',array('class'=>'error-message'));
		$this->redirect(array('action' => 'index'));
	}
}
?>