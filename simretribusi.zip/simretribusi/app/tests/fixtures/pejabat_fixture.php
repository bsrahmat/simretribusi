<?php
/* Pejabat Fixture generated on: 2010-11-23 16:11:12 : 1290505452 */
class PejabatFixture extends CakeTestFixture {
	var $name = 'Pejabat';

	var $fields = array(
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(

		),
	);
}
?>