<?php
/* Pemungut Fixture generated on: 2010-11-23 16:11:14 : 1290505454 */
class PemungutFixture extends CakeTestFixture {
	var $name = 'Pemungut';

	var $fields = array(
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(

		),
	);
}
?>