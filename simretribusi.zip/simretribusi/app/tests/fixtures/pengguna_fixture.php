<?php
/* Pengguna Fixture generated on: 2010-11-23 16:11:15 : 1290505455 */
class PenggunaFixture extends CakeTestFixture {
	var $name = 'Pengguna';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'length' => 10, 'key' => 'primary'),
		'namauser' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 30, 'key' => 'unique', 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'sandi' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 50, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'nama' => array('type' => 'string', 'null' => false, 'default' => NULL, 'length' => 100, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'level' => array('type' => 'string', 'null' => false, 'default' => '1', 'length' => 50, 'collate' => 'latin1_swedish_ci', 'comment' => '1=ADMINISTRATOR', 'charset' => 'latin1'),
		'lastlogin' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'jumlahlogin' => array('type' => 'integer', 'null' => false, 'default' => '0'),
		'aktif' => array('type' => 'integer', 'null' => false, 'default' => '1', 'length' => 4, 'comment' => '1=aktif, 0=non aktif'),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'modified' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1), 'namauser' => array('column' => 'namauser', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'namauser' => 'Lorem ipsum dolor sit amet',
			'sandi' => 'Lorem ipsum dolor sit amet',
			'nama' => 'Lorem ipsum dolor sit amet',
			'level' => 'Lorem ipsum dolor sit amet',
			'lastlogin' => '2010-11-23 16:44:15',
			'jumlahlogin' => 1,
			'aktif' => 1,
			'created' => '2010-11-23 16:44:15',
			'modified' => '2010-11-23 16:44:15'
		),
	);
}
?>