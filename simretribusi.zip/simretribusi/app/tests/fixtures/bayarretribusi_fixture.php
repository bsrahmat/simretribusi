<?php
/* Bayarretribusi Fixture generated on: 2010-11-23 16:11:07 : 1290505447 */
class BayarretribusiFixture extends CakeTestFixture {
	var $name = 'Bayarretribusi';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'key' => 'primary'),
		'tanggal' => array('type' => 'date', 'null' => false, 'default' => NULL),
		'skrd_id' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'nobukti' => array('type' => 'string', 'null' => false, 'default' => NULL, 'key' => 'unique', 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'jumlahbayar' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'keterangan' => array('type' => 'text', 'null' => false, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'pembayar' => array('type' => 'string', 'null' => false, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'lock' => array('type' => 'string', 'null' => false, 'default' => 'T', 'length' => 1, 'collate' => 'latin1_swedish_ci', 'comment' => 'Y / T', 'charset' => 'latin1'),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'modified' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1), 'nobukti' => array('column' => 'nobukti', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'tanggal' => '2010-11-23',
			'skrd_id' => 1,
			'nobukti' => 'Lorem ipsum dolor sit amet',
			'jumlahbayar' => 1,
			'keterangan' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'pembayar' => 'Lorem ipsum dolor sit amet',
			'lock' => 'Lorem ipsum dolor sit ame',
			'created' => '2010-11-23 16:44:07',
			'modified' => '2010-11-23 16:44:07'
		),
	);
}
?>