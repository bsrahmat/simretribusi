<?php
/* Skrd Fixture generated on: 2010-11-23 16:11:20 : 1290505460 */
class SkrdFixture extends CakeTestFixture {
	var $name = 'Skrd';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'length' => 10, 'key' => 'primary'),
		'perusahaan_id' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'tahun' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'nosurat' => array('type' => 'string', 'null' => false, 'default' => NULL, 'key' => 'unique', 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'tglsurat' => array('type' => 'date', 'null' => false, 'default' => NULL),
		'tglbatas' => array('type' => 'date', 'null' => false, 'default' => NULL),
		'nilaiperbulan' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'length' => 10),
		'nilaipertahun' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'length' => 10),
		'belumdibayar' => array('type' => 'integer', 'null' => true, 'default' => NULL, 'length' => 10),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'modified' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1), 'nosurat' => array('column' => 'nosurat', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'perusahaan_id' => 1,
			'tahun' => 1,
			'nosurat' => 'Lorem ipsum dolor sit amet',
			'tglsurat' => '2010-11-23',
			'tglbatas' => '2010-11-23',
			'nilaiperbulan' => 1,
			'nilaipertahun' => 1,
			'belumdibayar' => 1,
			'created' => '2010-11-23 16:44:20',
			'modified' => '2010-11-23 16:44:20'
		),
	);
}
?>