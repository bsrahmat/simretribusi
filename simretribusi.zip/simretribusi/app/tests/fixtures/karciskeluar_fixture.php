<?php
/* Karciskeluar Fixture generated on: 2010-11-23 16:11:09 : 1290505449 */
class KarciskeluarFixture extends CakeTestFixture {
	var $name = 'Karciskeluar';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'key' => 'primary'),
		'tanggal' => array('type' => 'date', 'null' => false, 'default' => NULL),
		'karcismasuk_id' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'nokarcis' => array('type' => 'string', 'null' => false, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'jumlahlembar' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'jumlahbendel' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'nilaiperlembar' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'nilairupiah' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'keterangan' => array('type' => 'string', 'null' => true, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'pemungut_id' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'karcisblmdisetor' => array('type' => 'integer', 'null' => true, 'default' => NULL),
		'lock' => array('type' => 'string', 'null' => false, 'default' => 'T', 'length' => 1, 'collate' => 'latin1_swedish_ci', 'comment' => 'Y / T', 'charset' => 'latin1'),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'modified' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'tanggal' => '2010-11-23',
			'karcismasuk_id' => 1,
			'nokarcis' => 'Lorem ipsum dolor sit amet',
			'jumlahlembar' => 1,
			'jumlahbendel' => 1,
			'nilaiperlembar' => 1,
			'nilairupiah' => 1,
			'keterangan' => 'Lorem ipsum dolor sit amet',
			'pemungut_id' => 1,
			'karcisblmdisetor' => 1,
			'lock' => 'Lorem ipsum dolor sit ame',
			'created' => '2010-11-23 16:44:09',
			'modified' => '2010-11-23 16:44:09'
		),
	);
}
?>