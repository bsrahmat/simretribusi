<?php
/* Karcismasuk Fixture generated on: 2010-11-23 16:11:10 : 1290505450 */
class KarcismasukFixture extends CakeTestFixture {
	var $name = 'Karcismasuk';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'key' => 'primary'),
		'tanggal' => array('type' => 'date', 'null' => false, 'default' => NULL),
		'nokarcis' => array('type' => 'string', 'null' => false, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'jumlahlembar' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'nilaiperlembar' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'nilairupiah' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'keterangan' => array('type' => 'text', 'null' => true, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'stokkarcis' => array('type' => 'integer', 'null' => true, 'default' => NULL),
		'lock' => array('type' => 'string', 'null' => false, 'default' => 'T', 'length' => 1, 'collate' => 'latin1_swedish_ci', 'comment' => 'Y / T', 'charset' => 'latin1'),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'modified' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'tanggal' => '2010-11-23',
			'nokarcis' => 'Lorem ipsum dolor sit amet',
			'jumlahlembar' => 1,
			'nilaiperlembar' => 1,
			'nilairupiah' => 1,
			'keterangan' => 'Lorem ipsum dolor sit amet, aliquet feugiat. Convallis morbi fringilla gravida, phasellus feugiat dapibus velit nunc, pulvinar eget sollicitudin venenatis cum nullam, vivamus ut a sed, mollitia lectus. Nulla vestibulum massa neque ut et, id hendrerit sit, feugiat in taciti enim proin nibh, tempor dignissim, rhoncus duis vestibulum nunc mattis convallis.',
			'stokkarcis' => 1,
			'lock' => 'Lorem ipsum dolor sit ame',
			'created' => '2010-11-23 16:44:10',
			'modified' => '2010-11-23 16:44:10'
		),
	);
}
?>