<?php
/* Setorkarcis Fixture generated on: 2010-11-23 16:11:19 : 1290505459 */
class SetorkarcisFixture extends CakeTestFixture {
	var $name = 'Setorkarcis';

	var $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => NULL, 'key' => 'primary'),
		'tanggal' => array('type' => 'date', 'null' => false, 'default' => NULL),
		'karciskeluar_id' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'pemungut' => array('type' => 'string', 'null' => true, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'nokarcis' => array('type' => 'string', 'null' => false, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'jumlahlembar' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'jumlahrupiah' => array('type' => 'integer', 'null' => false, 'default' => NULL),
		'keterangan' => array('type' => 'string', 'null' => true, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'penyetor' => array('type' => 'string', 'null' => true, 'default' => NULL, 'collate' => 'latin1_swedish_ci', 'charset' => 'latin1'),
		'lock' => array('type' => 'string', 'null' => false, 'default' => 'T', 'length' => 1, 'collate' => 'latin1_swedish_ci', 'comment' => 'Y / T', 'charset' => 'latin1'),
		'created' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'modified' => array('type' => 'datetime', 'null' => true, 'default' => NULL),
		'indexes' => array('PRIMARY' => array('column' => 'id', 'unique' => 1)),
		'tableParameters' => array('charset' => 'latin1', 'collate' => 'latin1_swedish_ci', 'engine' => 'MyISAM')
	);

	var $records = array(
		array(
			'id' => 1,
			'tanggal' => '2010-11-23',
			'karciskeluar_id' => 1,
			'pemungut' => 'Lorem ipsum dolor sit amet',
			'nokarcis' => 'Lorem ipsum dolor sit amet',
			'jumlahlembar' => 1,
			'jumlahrupiah' => 1,
			'keterangan' => 'Lorem ipsum dolor sit amet',
			'penyetor' => 'Lorem ipsum dolor sit amet',
			'lock' => 'Lorem ipsum dolor sit ame',
			'created' => '2010-11-23 16:44:19',
			'modified' => '2010-11-23 16:44:19'
		),
	);
}
?>