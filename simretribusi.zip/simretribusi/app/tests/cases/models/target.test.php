<?php
/* Target Test cases generated on: 2010-11-23 16:11:22 : 1290505462*/
App::import('Model', 'Target');

class TargetTestCase extends CakeTestCase {
	var $fixtures = array('app.target');

	function startTest() {
		$this->Target =& ClassRegistry::init('Target');
	}

	function endTest() {
		unset($this->Target);
		ClassRegistry::flush();
	}

}
?>