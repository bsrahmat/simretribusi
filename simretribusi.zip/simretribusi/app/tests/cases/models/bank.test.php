<?php
/* Bank Test cases generated on: 2010-11-23 16:11:06 : 1290505446*/
App::import('Model', 'Bank');

class BankTestCase extends CakeTestCase {
	var $fixtures = array('app.bank');

	function startTest() {
		$this->Bank =& ClassRegistry::init('Bank');
	}

	function endTest() {
		unset($this->Bank);
		ClassRegistry::flush();
	}

}
?>