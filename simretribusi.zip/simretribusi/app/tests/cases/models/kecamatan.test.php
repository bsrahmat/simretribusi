<?php
/* Kecamatan Test cases generated on: 2010-11-23 16:11:11 : 1290505451*/
App::import('Model', 'Kecamatan');

class KecamatanTestCase extends CakeTestCase {
	var $fixtures = array('app.kecamatan', 'app.perusahaan');

	function startTest() {
		$this->Kecamatan =& ClassRegistry::init('Kecamatan');
	}

	function endTest() {
		unset($this->Kecamatan);
		ClassRegistry::flush();
	}

}
?>