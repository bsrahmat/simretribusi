<?php
/* Perusahaan Test cases generated on: 2010-11-23 16:11:18 : 1290505458*/
App::import('Model', 'Perusahaan');

class PerusahaanTestCase extends CakeTestCase {
	var $fixtures = array('app.perusahaan', 'app.kecamatan');

	function startTest() {
		$this->Perusahaan =& ClassRegistry::init('Perusahaan');
	}

	function endTest() {
		unset($this->Perusahaan);
		ClassRegistry::flush();
	}

}
?>