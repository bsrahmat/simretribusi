<?php
/* Karciskeluar Test cases generated on: 2010-11-23 16:11:09 : 1290505449*/
App::import('Model', 'Karciskeluar');

class KarciskeluarTestCase extends CakeTestCase {
	var $fixtures = array('app.karciskeluar', 'app.karcismasuk', 'app.pemungut', 'app.setorkarcis');

	function startTest() {
		$this->Karciskeluar =& ClassRegistry::init('Karciskeluar');
	}

	function endTest() {
		unset($this->Karciskeluar);
		ClassRegistry::flush();
	}

}
?>