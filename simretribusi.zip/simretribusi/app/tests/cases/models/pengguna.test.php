<?php
/* Pengguna Test cases generated on: 2010-11-23 16:11:15 : 1290505455*/
App::import('Model', 'Pengguna');

class PenggunaTestCase extends CakeTestCase {
	var $fixtures = array('app.pengguna');

	function startTest() {
		$this->Pengguna =& ClassRegistry::init('Pengguna');
	}

	function endTest() {
		unset($this->Pengguna);
		ClassRegistry::flush();
	}

}
?>