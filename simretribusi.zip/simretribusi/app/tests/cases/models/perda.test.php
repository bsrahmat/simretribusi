<?php
/* Perda Test cases generated on: 2010-11-23 16:11:16 : 1290505456*/
App::import('Model', 'Perda');

class PerdaTestCase extends CakeTestCase {
	var $fixtures = array('app.perda');

	function startTest() {
		$this->Perda =& ClassRegistry::init('Perda');
	}

	function endTest() {
		unset($this->Perda);
		ClassRegistry::flush();
	}

}
?>