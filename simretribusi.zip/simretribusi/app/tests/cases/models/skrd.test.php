<?php
/* Skrd Test cases generated on: 2010-11-23 16:11:20 : 1290505460*/
App::import('Model', 'Skrd');

class SkrdTestCase extends CakeTestCase {
	var $fixtures = array('app.skrd', 'app.perusahaan', 'app.kecamatan', 'app.bayarretribusi');

	function startTest() {
		$this->Skrd =& ClassRegistry::init('Skrd');
	}

	function endTest() {
		unset($this->Skrd);
		ClassRegistry::flush();
	}

}
?>