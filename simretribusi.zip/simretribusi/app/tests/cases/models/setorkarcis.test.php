<?php
/* Setorkarcis Test cases generated on: 2010-11-23 16:11:19 : 1290505459*/
App::import('Model', 'Setorkarcis');

class SetorkarcisTestCase extends CakeTestCase {
	var $fixtures = array('app.setorkarcis', 'app.karciskeluar', 'app.karcismasuk', 'app.pemungut');

	function startTest() {
		$this->Setorkarcis =& ClassRegistry::init('Setorkarcis');
	}

	function endTest() {
		unset($this->Setorkarcis);
		ClassRegistry::flush();
	}

}
?>