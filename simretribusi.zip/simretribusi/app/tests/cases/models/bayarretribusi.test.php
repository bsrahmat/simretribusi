<?php
/* Bayarretribusi Test cases generated on: 2010-11-23 16:11:07 : 1290505447*/
App::import('Model', 'Bayarretribusi');

class BayarretribusiTestCase extends CakeTestCase {
	var $fixtures = array('app.bayarretribusi', 'app.skrd');

	function startTest() {
		$this->Bayarretribusi =& ClassRegistry::init('Bayarretribusi');
	}

	function endTest() {
		unset($this->Bayarretribusi);
		ClassRegistry::flush();
	}

}
?>