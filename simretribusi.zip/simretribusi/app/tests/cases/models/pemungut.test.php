<?php
/* Pemungut Test cases generated on: 2010-11-23 16:11:14 : 1290505454*/
App::import('Model', 'Pemungut');

class PemungutTestCase extends CakeTestCase {
	var $fixtures = array('app.pemungut');

	function startTest() {
		$this->Pemungut =& ClassRegistry::init('Pemungut');
	}

	function endTest() {
		unset($this->Pemungut);
		ClassRegistry::flush();
	}

}
?>