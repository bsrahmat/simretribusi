<?php
/* Pejabat Test cases generated on: 2010-11-23 16:11:13 : 1290505453*/
App::import('Model', 'Pejabat');

class PejabatTestCase extends CakeTestCase {
	var $fixtures = array('app.pejabat');

	function startTest() {
		$this->Pejabat =& ClassRegistry::init('Pejabat');
	}

	function endTest() {
		unset($this->Pejabat);
		ClassRegistry::flush();
	}

}
?>