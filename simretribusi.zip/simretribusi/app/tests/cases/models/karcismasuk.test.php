<?php
/* Karcismasuk Test cases generated on: 2010-11-23 16:11:10 : 1290505450*/
App::import('Model', 'Karcismasuk');

class KarcismasukTestCase extends CakeTestCase {
	var $fixtures = array('app.karcismasuk', 'app.karciskeluar', 'app.pemungut', 'app.setorkarcis');

	function startTest() {
		$this->Karcismasuk =& ClassRegistry::init('Karcismasuk');
	}

	function endTest() {
		unset($this->Karcismasuk);
		ClassRegistry::flush();
	}

}
?>