<?php
class Perda extends AppModel {
	var $name = 'Perda';
	var $validate = array(
		'perda' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nomor dan Tahun Perda harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'tentang' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Data harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
}
?>