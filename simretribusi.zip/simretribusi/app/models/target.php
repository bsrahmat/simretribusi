<?php
class Target extends AppModel {
	var $name = 'Target';
	var $validate = array(
		'tahun' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
			),
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Tahun harus diisi',
			),
			'isUnique' => array(
				'rule' => array('isUnique'),
				'message' => 'Tahun tidak boleh sama',
			),
			'minLength' => array(
				'rule' => array('minLength','4'),
				'message' => 'Harus 4 digit angka',
			),
			'maxLength' => array(
				'rule' => array('maxLength','4'),
				'message' => 'Harus 4 digit angka',
			),
		),
		'kreditapbd' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Kredit APBD harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
}
?>