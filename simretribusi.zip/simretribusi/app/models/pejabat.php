<?php
class Pejabat extends AppModel {
	var $name = 'Pejabat';
	var $validate = array(
		'jabatan' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Jabatan harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'nama' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nama harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'nip' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'NIP harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
}
?>