<?php
class Karciskeluar extends AppModel {
	var $name = 'Karciskeluar';
	var $virtualFields = array(
		'name' => 'CONCAT(DATE_FORMAT(Karciskeluar.tanggal,"%e-%b-%Y"), "; Pemungut: ", pemungut_nama, " (no.seri:", Karciskeluar.nokarcis, "; nominal=", Karciskeluar.nilaiperlembar, "; Jumlah karcis belum disetor=", Karciskeluar.karcisblmdisetor, ")")',
	);
	var $displayField = 'name';
	var $validate = array(
		'tanggal' => array(
			'date' => array(
				'rule' => array('date'),
				'message' => 'Data tidak valid',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'karcismasuk_id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'nokarcis' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nomor Seri Karcis harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'jumlahlembar' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
				'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'jumlahbendel' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
				'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'nilaiperlembar' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
				'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'nilairupiah' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'pemungut_id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'Karcismasuk' => array(
			'className' => 'Karcismasuk',
			'foreignKey' => 'karcismasuk_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		),
		'Pemungut' => array(
			'className' => 'Pemungut',
			'foreignKey' => 'pemungut_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);

	var $hasMany = array(
		'Setorkarcis' => array(
			'className' => 'Setorkarcis',
			'foreignKey' => 'karciskeluar_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>