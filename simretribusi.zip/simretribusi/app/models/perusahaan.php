<?php
class Perusahaan extends AppModel {
	var $name = 'Perusahaan';
	var $actsAs = array('Containable');
	var $displayField = 'nama';
	var $validate = array(
		'nama' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nama Perusahaan harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			'isUnique' => array(
				'rule' => array('isUnique'),
				'message' => 'Nama Perusahaan sudah ada',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'alamat' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Alamat harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'kecamatan_id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nama Kecamatan harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'luas' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi dengan angka saja',
				'allowEmpty' => true,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'jmlkaryawan' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi dengan angka saja',
				'allowEmpty' => true,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'Kecamatan' => array(
			'className' => 'Kecamatan',
			'foreignKey' => 'kecamatan_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);

	var $hasMany = array(
		'Skrd' => array(
			'className' => 'Skrd',
			'foreignKey' => 'perusahaan_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>