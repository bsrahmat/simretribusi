<?php
class Setorkarcis extends AppModel {
	var $name = 'Setorkarcis';
	var $validate = array(
		'tanggal' => array(
			'date' => array(
				'rule' => array('date'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
			),
		),
		'karciskeluar_id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				//'message' => 'Your custom message here',
			),
		),
		'nokarcis' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'No. Seri Karcis harus diisi',
			),
		),
		'jumlahlembar' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi dengan angka saja',
				'allowEmpty' => false,
			),
		),
		'jumlahrupiah' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi dengan angka saja',
				'allowEmpty' => false,
			),
		),
		'penyetor' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nam Penyetor harus diisi',
			),
		),
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'Karciskeluar' => array(
			'className' => 'Karciskeluar',
			'foreignKey' => 'karciskeluar_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);
}
?>