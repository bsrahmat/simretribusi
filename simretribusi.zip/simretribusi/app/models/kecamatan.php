<?php
class Kecamatan extends AppModel {
	var $name = 'Kecamatan';
	var $displayField = 'nama';
	var $validate = array(
		'nama' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Data harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			'isUnique' => array(
				'rule' => array('isUnique'),
				'message' => 'Data sudah ada',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $hasMany = array(
		'Perusahaan' => array(
			'className' => 'Perusahaan',
			'foreignKey' => 'kecamatan_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>