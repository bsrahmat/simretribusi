<?php

class User extends AppModel {
	var $name = 'User';
	var $displayField = 'username';
	var $validate = array(
		'username' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Username tidak boleh kosong',
			),
			'unik' => array(
				'rule' => array('isUnique'),
				'message' => 'Username sudah digunakan',
			),
			'minlength' => array(
				'rule' => array('minlength','5'),
				'message' => 'Minimal 5 karakter',
			),
			'maxlength' => array(
				'rule' => array('maxlength','30'),
				'message' => 'Username maksimal 30 karakter',
			),
		),
		'password' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Password harus diisi !',
			),
			'minlength' => array(
				'rule' => array('minlength','8'),
				'message' => 'Password minimal 8 karakter (huruf/angka)',
			),
		),
		'nama' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nama Lengkap harus diisi',
			),
		),/*
		'level' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Level user harus dipilih',
			),
		),*/
	);
}
?>