<?php
class Karcismasuk extends AppModel {
	var $name = 'Karcismasuk';
	var $virtualFields = array(
		'name' => 'CONCAT(DATE_FORMAT(Karcismasuk.tanggal,"%e-%b-%Y")," (no.seri:",Karcismasuk.nokarcis,"; nominal=",Karcismasuk.nilaiperlembar,"; stok=",Karcismasuk.stokkarcis,")")',
	);
	var $displayField = 'name';
	var $validate = array(
		'tanggal' => array(
			'date' => array(
				'rule' => array('date'),
				'message' => 'Tanggal harus diisi',
				'allowEmpty' => false,
			),
		),
		'nokarcis' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nomor Seri Karcis harus diisi',
			),
		),
		'jumlahlembar' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi dengan angka saja',
			),
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Jumlah Lembar Karcis harus diisi',
			),
		),
		'nilaiperlembar' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi dengan angka saja',
			),
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nilai Per Lembar Karcis harus diisi',
			),
		),
		'nilairupiah' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi dengan angka saja',
				'allowEmpty' => false,
			),
		),
		'stokkarcis' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi dengan angka saja',
			),
		),
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $hasMany = array(
		'Karciskeluar' => array(
			'className' => 'Karciskeluar',
			'foreignKey' => 'karcismasuk_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>