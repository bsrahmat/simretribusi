<?php
class Bank extends AppModel {
	var $name = 'Bank';
	var $validate = array(
		'skpd' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Data harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'koderekening' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Kode rekening harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'namarekening' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nama rekening harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
}
?>