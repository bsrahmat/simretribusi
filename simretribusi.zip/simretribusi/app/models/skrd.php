<?php
class Skrd extends AppModel {
	var $name = 'Skrd';
	var $validate = array(
		'perusahaan_id' => array(
			'numeric' => array(
				'rule' => array('numeric'),
			),
		),
		'tahun' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
			),
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Tahun harus diisi',
			),
			'minLength' => array(
				'rule' => array('minLength','4'),
				'message' => 'Harus 4 digit angka',
			),
			'maxLength' => array(
				'rule' => array('maxLength','4'),
				'message' => 'Harus 4 digit angka',
			),
		),
		'nosurat' => array(
			'notempty' => array(
				'rule' => array('notempty'),
				'message' => 'Nomor surat harus diisi',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
			'isUnique' => array(
				'rule' => array('isUnique'),
				'message' => 'Nomor surat sudah ada. Harap diganti',
			),
		),
		'tglsurat' => array(
			'date' => array(
				'rule' => array('date'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'tglbatas' => array(
			'date' => array(
				'rule' => array('date'),
				//'message' => 'Your custom message here',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'nilaiperbulan' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
		'nilaipertahun' => array(
			'numeric' => array(
				'rule' => array('numeric'),
				'message' => 'Mohon diisi angka saja',
				//'allowEmpty' => false,
				//'required' => false,
				//'last' => false, // Stop validation after this rule
				//'on' => 'create', // Limit validation to 'create' or 'update' operations
			),
		),
	);
	//The Associations below have been created with all possible keys, those that are not needed can be removed

	var $belongsTo = array(
		'Perusahaan' => array(
			'className' => 'Perusahaan',
			'foreignKey' => 'perusahaan_id',
			'conditions' => '',
			'fields' => '',
			'order' => ''
		)
	);

	var $hasMany = array(
		'Bayarretribusi' => array(
			'className' => 'Bayarretribusi',
			'foreignKey' => 'skrd_id',
			'dependent' => false,
			'conditions' => '',
			'fields' => '',
			'order' => '',
			'limit' => '',
			'offset' => '',
			'exclusive' => '',
			'finderQuery' => '',
			'counterQuery' => ''
		)
	);

}
?>