<?php
/**
 * Created by Abu Zaid
 */

class AppHelper extends Helper {
	function cetak($nilai) {
		if (!empty($nilai))
			return $nilai;
		else
			return '-';
	}
	function rupiah($nilai,$rp=true){
		if (!empty($nilai)){
			if ($rp)
				return 'Rp '.number_format($nilai,0,',','.').',-';
			else
				return number_format($nilai,0,',','.').',-';
		}
		else return '-';
	}
	function rupiahReport($nilai,$dec=null){
		if (!empty($nilai)){
			if ($dec==null)
				return number_format($nilai,2,',','.');
			else
				return number_format($nilai,0,',','.');
		}
		else return '-';
	}
	function bulanTahun($tgl) {
		if (!empty($tgl)){
			$bln = '';
			switch (date('n',strtotime($tgl))) {
				case 1: $bln = 'Januari'; break;
				case 2: $bln = 'Februari'; break;
				case 3: $bln = 'Maret'; break;
				case 4: $bln = 'April'; break;
				case 5: $bln = 'Mei'; break;
				case 6: $bln = 'Juni'; break;
				case 7: $bln = 'Juli'; break;
				case 8: $bln = 'Agustus'; break;
				case 9: $bln = 'September'; break;
				case 10: $bln = 'Oktober'; break;
				case 11: $bln = 'Nopember'; break;
				case 12: $bln = 'Desember'; break;
			}
			$y = date('Y',strtotime($tgl));
			$hasil = $bln.' '.$y;
			return $hasil;
		}
		else
			return '-';
	}
	function formatTglDmyView($tgl,$hub=null) {
		if (!empty($tgl)) {
			if ($hub!=null)
				return date('d'.$hub.'m'.$hub.'Y',strtotime($tgl));
			else
				return date('d/m/Y',strtotime($tgl));
		}
		else
			return $tgl;
	}
	function formatTglIndonesia($tgl) {
		if (!empty($tgl)){
			$d = date('d',strtotime($tgl));
			$bln = '';
			switch (date('n',strtotime($tgl))) {
				case 1: $bln = 'Januari'; break;
				case 2: $bln = 'Februari'; break;
				case 3: $bln = 'Maret'; break;
				case 4: $bln = 'April'; break;
				case 5: $bln = 'Mei'; break;
				case 6: $bln = 'Juni'; break;
				case 7: $bln = 'Juli'; break;
				case 8: $bln = 'Agustus'; break;
				case 9: $bln = 'September'; break;
				case 10: $bln = 'Oktober'; break;
				case 11: $bln = 'Nopember'; break;
				case 12: $bln = 'Desember'; break;
			}
			$y = date('Y',strtotime($tgl));
			$hasil = $d.' '.$bln.' '.$y;
			return $hasil;
		}
		else
			return $tgl;
	}
	function formatTglIndonesiaSingkat($tgl) {
		if (!empty($tgl)){
			$d = date('d',strtotime($tgl));
			$bln = '';
			switch (date('n',strtotime($tgl))) {
				case 1: $bln = 'Jan'; break;
				case 2: $bln = 'Feb'; break;
				case 3: $bln = 'Mar'; break;
				case 4: $bln = 'Apr'; break;
				case 5: $bln = 'Mei'; break;
				case 6: $bln = 'Jun'; break;
				case 7: $bln = 'Jul'; break;
				case 8: $bln = 'Agst'; break;
				case 9: $bln = 'Sep'; break;
				case 10: $bln = 'Okt'; break;
				case 11: $bln = 'Nop'; break;
				case 12: $bln = 'Des'; break;
			}
			$y = date('Y',strtotime($tgl));
			$hasil = $d.' '.$bln.' '.$y;
			return $hasil;
		}
		else
			return $tgl;
	}
	function hari_ini(){
		$hari    = date('w');
		$tanggal = date('d');
		$bulan   = date('m');
		$tahun   = date('Y');

		//mengubah kode hari dari angka menjadi nama hari
		if($hari==0){ $hari = "Minggu";
		} else if($hari==1){ $hari = "Senin";
		} else if($hari==2){ $hari = "Selasa";
		} else if($hari==3){ $hari = "Rabu";
		} else if($hari==4){ $hari = "Kamis";
		} else if($hari==5){$hari = "Jumat";
		} else if($hari==6){ $hari = "Sabtu";}

		//mengubah kode bulan dari angka menjadi nama bulan
		if($bulan==01){ $bulan = "Januari";
		} else if($bulan==02){ $bulan = "Februari";
		} else if($bulan==03){ $bulan = "Maret";
		} else if($bulan==04){ $bulan = "April";
		} else if($bulan==05){ $bulan = "Mei";
		} else if($bulan==06){ $bulan = "Juni";
		} else if($bulan==07){ $bulan = "Juli";
		} else if($bulan==08){ $bulan = "Agustus";
		} else if($bulan==09){ $bulan = "September";
		} else if($bulan==10){ $bulan = "Oktober";
		} else if($bulan==11){ $bulan = "Nopember";
		} else if($bulan==12){ $bulan = "Desember";}

		//menampilkan hari, tanggal, bulan, dan tahun
		return "$hari, $tanggal $bulan $tahun";
	}
}
?>
