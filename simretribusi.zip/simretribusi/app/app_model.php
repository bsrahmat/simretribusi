<?php
/*
 * Created by Abu Zaid
 */
class AppModel extends Model {
	var $actsAs = array('Containable');
}
?>
