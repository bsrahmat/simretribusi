<?php
/**
 * Created by Abu Zaid
 * Date : 5 November 2010
 * e-mail support : adibomo@gmail.com
 */
class AppController extends Controller {
	var $helpers = array('Html','Form','Javascript','Session','Text');
	var $components = array('Auth','Session');

	function beforeFilter(){
		$this->Auth->loginError = "Nama User / Kata Sandi salah !";
    	$this->Auth->authError = "Silahkan Login dahulu.";
		if ($this->action=='login')
			$this->layout = 'loginuser';
		if ($this->Auth->user()==null) {
			if ($this->action!='register')
				$this->layout = 'loginuser';
		} else {
			$dtlogin = $this->Auth->user();
			$this->set(compact('dtlogin'));
		}
	}
	function backlink(){
		$asal = "/";
		if ((!empty($_SERVER["HTTP_REFERER"])) && (substr_count($_SERVER["HTTP_REFERER"],$_SERVER["SERVER_NAME"])==1)) $asal = $_SERVER["HTTP_REFERER"];
		return $asal;
	}
	function kekata($x) {
	   $x = abs($x);
	   $angka = array("", "satu", "dua", "tiga", "empat", "lima",
	   "enam", "tujuh", "delapan", "sembilan", "sepuluh", "sebelas");
	   $temp = "";
	   if ($x <12) {
	       $temp = " ". $angka[$x];
	   } else if ($x <20) {
	       $temp = $this->kekata($x - 10). " belas";
	   } else if ($x <100) {
	       $temp = $this->kekata($x/10)." puluh". $this->kekata($x % 10);
	   } else if ($x <200) {
	       $temp = " seratus" . $this->kekata($x - 100);
	   } else if ($x <1000) {
	       $temp = $this->kekata($x/100) . " ratus" . $this->kekata($x % 100);
	   } else if ($x <2000) {
	       $temp = " seribu" . $this->kekata($x - 1000);
	   } else if ($x <1000000) {
	       $temp = $this->kekata($x/1000) . " ribu" . $this->kekata($x % 1000);
	   } else if ($x <1000000000) {
	       $temp = $this->kekata($x/1000000) . " juta" . $this->kekata($x % 1000000);
	   } else if ($x <1000000000000) {
	       $temp = $this->kekata($x/1000000000) . " milyar" . $this->kekata(fmod($x,1000000000));
	   } else if ($x <1000000000000000) {
	       $temp = $this->kekata($x/1000000000000) . " trilyun" . $this->kekata(fmod($x,1000000000000));
	   }
	       return $temp;
	}
	function terbilang($x, $style=4) {
	   if($x<0) {
	       $hasil = "minus ". trim($this->kekata($x));
	   } else {
	       $hasil = trim($this->kekata($x));
	   }
	   switch ($style) {
	       case 1:
	           $hasil = strtoupper($hasil);
	           break;
	       case 2:
	           $hasil = strtolower($hasil);
	           break;
	       case 3:
	           $hasil = ucwords($hasil);
	           break;
	       default:
	           $hasil = ucfirst($hasil);
	           break;
	   }
	   return $hasil;
	}
}
?>