<?php
class DATABASE_CONFIG {

	var $default = array(
		'driver' => 'mysql',
		'persistent' => false,
		'host' => 'localhost',
		'login' => 'ristekom_root',
		'password' => 'bismillah123',
		'database' => 'ristekom_demosimretribusi',
		'prefix' => '',
	);
}
